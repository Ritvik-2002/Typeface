import java.util.*;

class Wallet {
    String name; // Wanted to have this as unquie constraint 
    double balance;
    long createdAt = System.currentTimeMillis();            
    List<String> statement = new ArrayList<>();
    int transactions = 0;

    Double fdAmount = null;              
    int remainingTxn = 0;

    Wallet(String name, double balance) {
        if(balance < 0){
            System.out.println("BALANCE CANNOT BE NEGATIVE WALLET HAS NOT CREATED");
            return;
        }
        this.name = name;
        this.balance = balance;
    }

    void addStatement(String s) {
        statement.add(s);
        transactions++;
        if (fdAmount != null) {
            if (balance >= fdAmount) {
                remainingTxn--;
                if (remainingTxn == 0) {
                    balance += 10;
                    statement.add("FD INTREST CREDIT 10");
                    fdAmount = null;
                }
            } else {
                fdAmount = null;
                remainingTxn = 0;
            }
        }
    }
}
