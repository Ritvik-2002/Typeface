import java.util.*;

public class UPI {
   HashMap<String, Wallet> map = new HashMap<>();

    public void createWallet(String name, double amount) {
        if(map.containsKey(name)){
            System.out.println("NAME ALREADY EXISTS");
            return;
        }
        map.put(name, new Wallet(name, amount));
    }

    public void transferMoney(String from, String to, double amount) {
        Wallet w1 = map.get(from);
        Wallet w2 = map.get(to);
        if(w1 == null || w2 == null){
            System.out.println("WALLET DOES NOT EXIST");
            return;
        }
        if(amount <  0.0001){
            System.out.println("THE MINIMUM AMOUNT THAT CAN BE TRANSFERRED IS 0.0001");
            return;
        }
        if(from.equals(to)){
            System.out.println("BOTH FROM AND TO ACCOUNTS CANNOT BE SAME");
            return;
        }
        if(w1.balance < amount){
            System.out.println("INSUFFICIENT BALANCE , AMOUNT IS NOT DEBITED");
            return;
        }
        w1.balance -= amount;
        w2.balance += amount;
        w1.addStatement(to + " DEBIT " + amount);
        w2.addStatement(from + " CREDIT " + amount);
        if (w1.balance == w2.balance) {
            w1.balance += 10;
            w2.balance += 10;
            w1.statement.add("OFFER1 CREDIT 10"); // not considering this flow in fd (i.e not considering as txn)
            w2.statement.add("OFFER1 CREDIT 10"); // not considering this flow in fd (i.e not considering as txn)
        }
    }

    public void offer2() {
        ArrayList<Wallet> arr = new ArrayList<>(map.values());
        arr.sort((a, b) -> {
            if(b.transactions != a.transactions)
                return b.transactions - a.transactions;                
            if(Double.compare(b.balance, a.balance) != 0)
                return Double.compare(b.balance, a.balance);           
            return Long.compare(a.createdAt, b.createdAt);      
        });
        int rewards [] = {10, 5, 2};
        for (int i = 0; i < Math.min(3, arr.size()); i++) {
            Wallet w = arr.get(i);
            w.balance += rewards[i];
            w.statement.add("OFFER2 CREDIT " + rewards[i]); // not considering this flow in fd (i.e not considering as txn)
        }
    }

    public void statement(String name) {
        Wallet w = map.get(name);
        if(w == null){
            System.out.println("WALLET DOES NOT EXIST");
            return;
        }
        for(String s : w.statement) System.out.println(s);
        if(w.fdAmount != null)
            System.out.println("FD AMOUNT=" + w.fdAmount + " REMAINING-TXNS=" + w.remainingTxn);
    }

    public void overview() {
        for(Wallet w : map.values()) {
            System.out.print(w.name + " " + w.balance);
            if (w.fdAmount != null)
                System.out.print("   FD AMOUNT:" + w.fdAmount + " REMAINING-TXNS:" + w.remainingTxn);
            System.out.println();
        }
    }

    public void fixedDeposit(String name, double amount) {
        Wallet w = map.get(name);
        if(w == null){
            System.out.println("WALLET DOES NOT EXIST");
            return;
        }
        if (w.balance >= amount) {
            w.fdAmount = amount;
            w.remainingTxn = 5;
            w.statement.add("FD started " + amount);
        }
    } 
}
