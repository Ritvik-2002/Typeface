class Solution {
    public static void main(String[] args) {
        UPI fk_supermoney = new UPI();
        fk_supermoney.createWallet("Harry", 100);
        fk_supermoney.createWallet("Ron", 95.7);
        fk_supermoney.createWallet("Hermione", 104);
        fk_supermoney.createWallet("Albus", 200);
        fk_supermoney.createWallet("Draco", 500);
        System.out.println("----- Output 1 --------");
        fk_supermoney.overview();
        fk_supermoney.transferMoney("Albus", "Draco", 30);
        fk_supermoney.transferMoney("Hermione", "Harry", 2);
        fk_supermoney.transferMoney("Albus", "Ron", 5);
        System.out.println();
        System.out.println("----- Output 2 --------");
        fk_supermoney.overview();
        System.out.println();
        System.out.println("----- Output 3 --------");
        fk_supermoney.statement("Harry");
        System.out.println();
        System.out.println("----- Output 4 --------");
         fk_supermoney.statement("Albus");
        fk_supermoney.offer2();
        System.out.println();
        System.out.println("----- Output 5 --------");
        fk_supermoney.overview();
    }
}